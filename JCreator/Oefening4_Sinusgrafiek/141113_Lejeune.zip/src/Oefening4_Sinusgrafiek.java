/**
 * @(#)Oefening4_Sinusgrafiek.java
 *
 * Oefening4_Sinusgrafiek application
 * @author David Lejeune - 1PBICT
 * @version 1.00 2014/11/13
 *
 * Teken een sinusgrafiek op het scherm
 *
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
// eventueel extra imports hier

public class Oefening4_Sinusgrafiek extends JFrame {  
    
    public static void main(String[] argumentenRij) {
       JFrame frame = new Oefening4_Sinusgrafiek();
       frame.setSize(900,700);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setTitle("Oefening4_Sinusgrafiek");
         // naam aanpassen als je Paneel van naam wijzigt !!!
       Paneel paneel = new Paneel();
       frame.setContentPane( paneel );
       frame.setVisible(true);    	
    }
}

class Paneel extends JPanel {
    // declaraties van de variabelen, schrap wat je niet gebruikt !
    
    // referenties naar objecten 
  private JLabel labelAantal;
  private JLabel labelAmplitude;
  private JLabel labelBeginfase;
  private JTextField tekstvakAantal;
  private JTextField tekstvakAmplitude;
  private JTextField tekstvakBeginfase;
  private JButton knop;
    
    // primitieve variabelen
  boolean p;
  char    ch;
  int     i,j,k;
  double  r,s,t;
  
    // Constructor
  public Paneel() {
  	setLayout(null);
  	
	  // label aanmaken
	labelAantal = new JLabel (" Aantal ");	
	labelAmplitude = new JLabel (" Amplitude ");
	labelBeginfase = new JLabel (" Beginfase ");	
		
	labelAantal.setBounds(50,20,150,20);
	labelAmplitude.setBounds(150,20,200,20);
	labelBeginfase.setBounds(250,20,300,20); 
    labelAantal.setForeground (Color.GREEN);
    labelAmplitude.setForeground (Color.GREEN);
    labelBeginfase.setForeground (Color.GREEN);
	  
	  // knop aanmaken en koppelen met event-handler
    knop = new JButton( "GO" );
    knop.setBounds(350,50,80,30);
    knop.addActionListener( new KnopHandler() );
    
      // vak aanmaken op deze wijze ...
    tekstvakAantal = new JTextField(20);
    tekstvakAmplitude = new JTextField( 20);
    tekstvakBeginfase = new JTextField(20 );
    
    tekstvakAantal.setBounds(50,50,50,30);
    tekstvakAmplitude.setBounds(150,50,50,30);
    tekstvakBeginfase.setBounds(250,50,50,30); 
    
    
    
      // alle elementen toevoegen aan paneel-object
    add( labelAantal);
    add( labelAmplitude);
    add( labelBeginfase);
    add( knop );
    add( tekstvakAantal );
    add( tekstvakAmplitude );
    add( tekstvakBeginfase );
  }
     
      // alle tekenwerk hier
  public void paintComponent( Graphics g ) {
      super.paintComponent( g );
      // hier komen de tekenopdrachten
      
      
      g.setColor(Color.BLACK);
      g.fillRect(0,0,1000,800);
      
      
      g.setColor(Color.WHITE);
		g.drawLine(50,100,50,600);
		g.drawLine(50,350,820,350);
		    					
      
  }
  
      // interne klasse voor event-handler
  class KnopHandler implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
       // hier komen de event-handler opdrachten
       
       	Graphics g = getGraphics(); 

		int xStart = 50;
		int yStart = 350;
		int x=0;
		int y=0;
		double grad,rad;
		
  		double aantal = Double.parseDouble(tekstvakAantal.getText());
  		double amplitude= Double.parseDouble(tekstvakAmplitude.getText());
  		double beginfase = Double.parseDouble(tekstvakBeginfase.getText());
		
		if (amplitude > 250)
		{
			
      		g.setColor(Color.BLUE);
			String regel = "You need to stay within the bounds . 250 Amplitude";
			g.drawString(regel ,250 ,200);
		}
		if (amplitude < 250)
		{
		for (i = 0 ; i<720 ; i++)
		{
			
		// grad = Math.round (aantal * i / 2.0);
		
		rad = aantal * i / 2.0 * Math.PI / 180.0;
		double beginrad = beginfase * Math.PI / 180.0;
		//x = (int) Math.sin(x) ;
		// + Math.sin( Math.toRadians(beginfase) )
		y =(int)( yStart  - amplitude * Math.sin(rad + beginrad)  ) ;	
		
      	g.setColor(Color.YELLOW);
      	slaap(10);
      	g.fillOval(i + 50,y ,10,10);	
		 	
		 	
		}
		
		}
       // niet vergeten (indien nodig) :
       // validate();
       // repaint();
    }
  }
  
     // slaap routine, schrappen indien niet gebruikt
  public static void slaap (int mSec){		 
		try {
			Thread.currentThread().sleep(mSec); 
		} catch (InterruptedException e){ }
	} 
  
}